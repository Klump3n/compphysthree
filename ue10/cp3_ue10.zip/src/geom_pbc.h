#ifndef GEOM_PBC_H
#define GEOM_PBC_H

void geom_pbc(void);
void set_eo(void);

#endif
