#ifndef GEOM_PBC_H
#define GEOM_PBC_H

void geom_pbc(void);

#endif
