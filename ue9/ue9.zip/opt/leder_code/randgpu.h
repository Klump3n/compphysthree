#ifndef RANDOM_H
#define RANDOM_H

extern double* randgpu(unsigned int N);

#endif
