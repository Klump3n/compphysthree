#ifndef RANDOM_H
#define RANDOM_H

extern double* randgpu(unsigned int N);
extern double* randgpu_device_ptr(unsigned int N);

#endif
