#ifndef ADDED_STUFF_H
#define ADDED_STUFF_H

void evenOddIndices(int *evenArray, int *oddArray);
int indexEvenOdd(int *index_array);
void indexArray(int index, int *target_array);

#endif
